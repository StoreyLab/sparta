# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

##---(Thu Jun 12 11:23:59 2014)---
from collections import defaultdict
d = defaultdict(int)
d
d[a]
d['a']
s
d
d['b'] +=1
d
d.items()
clear
clear()
clc
clc()
import pysam
import itertools
import collections
bysam = pysam.Samfile('RM_bowtie_test/RM_bowtie_out.sam')
bysam = pysam.Samfile('RM_bowtie_test/RM_bowtie_out')
import os
os.ls()
os.list()
os.curdir()
os.path()
print os.path()
print os.path.curdir
print str(os.path.curdir())
print os.path.curdir()
os.getcwd()
os.chdir('git/SeqSorter/')
bysam = pysam.Samfile('RM_bowtie_test/RM_bowtie_out.sam')
os.chdir('sample_data')
bysam = pysam.Samfile('RM_bowtie_test/RM_bowtie_out.sam')
rmsam = pysam.Samfile('S288C_reference_genome_R64-1-1_20110203/S288C_reference_sequence_R64-1-1_20110203.fsa')
rmsam = pysam.Samfile('S288C_bowtie_test/BY_bowtie_out.sam')