# -*- coding: utf-8 -*-
"""
Spyder Editor

This temporary script file is located here:
/home/peter/.spyder2/.temp.py
"""

